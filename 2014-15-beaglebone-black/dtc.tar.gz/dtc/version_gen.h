#define DTC_VERSION "DTC 1.3.0-ge4b497f3-dirty"
